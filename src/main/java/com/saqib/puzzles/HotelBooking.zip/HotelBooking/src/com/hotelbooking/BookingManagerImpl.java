package com.hotelbooking;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.IntStream;

public class BookingManagerImpl implements BookingManager {
	
	private int[] rooms;
	private List<Booking> bookings = new CopyOnWriteArrayList<>();
	
	public boolean isRoomAvailable(Integer room, LocalDate date) {
		return bookings.stream().filter(r -> r.getDate().equals(date)).noneMatch(r -> r.getRoomNumber().equals(room));
	}
	
	
	// the problem here is ensuring thread safety of the check-then-act mechanism
	public synchronized void addBooking(String guest, Integer room, LocalDate date) {
		if (IntStream.of(rooms).noneMatch(x -> x == room)) throw new IllegalArgumentException("Invalid room number.");
		if (!isRoomAvailable(room, date)) throw new IllegalArgumentException("Already booked for that date.");
		Booking newBooking = new Booking(guest, date, room);
		bookings.add(newBooking);
	}

	public List<Integer> getAvailableRooms(LocalDate date) {
		List<Integer> listOfAvailableRooms = new ArrayList<>();
		IntStream.of(rooms).filter(x -> isRoomAvailable(x, date)).forEach(listOfAvailableRooms::add);
		return listOfAvailableRooms;
    }
	
	
	public BookingManagerImpl(int[] rooms) {
		this.rooms = rooms;
	}

	public static void main(String[] args) {
		BookingManager bm = new BookingManagerImpl(new int[] {101,102,201,203});
		LocalDate today = LocalDate.parse("2012-07-21");
		System.out.println(bm.isRoomAvailable(101, today)); // outputs true
		bm.addBooking("Smith", 101, today);
		System.out.println(bm.isRoomAvailable(101, today)); // outputs false
		bm.addBooking("Jones", 101, today); // throws an exception

	}

}
