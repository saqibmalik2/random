package com.hotelbooking;

import java.time.LocalDate;
import java.util.Objects;

final class Booking {

	final String name;
	final LocalDate date;
	final Integer roomNumber;
	
	public Booking(String name, LocalDate date, Integer roomNumber) {
		super();
		this.name = name;
		this.date = date;
		this.roomNumber = roomNumber;
	}
	
	public String getName() {
		return name;
	}

	public LocalDate getDate() {
		return date;
	}

	public Integer getRoomNumber() {
		return roomNumber;
	}
	
	
	@Override
	public boolean equals(Object o) {
		if (o == this) return true;
		if (!(o instanceof Booking)) return false;
		
		Booking booking = (Booking) o;
		  
		return	Objects.equals(date, booking.getDate()) &&
				Objects.equals(roomNumber, booking.getRoomNumber());
	}
	
	@Override
    public int hashCode() {
        return Objects.hash(date, roomNumber);
    }
	

}
